%progetto antenna satellitare controllata
%
%modello
clear; clc;
a=0.1;
Ts=1;
A=[0 1;0 -a];
B=[0;a];
C=[1 0];
D=[0];
C2=[0 1];%mi serve per vedere se lo stimatore � accurato
fprintf('il sistema in questione � rappresentato dalle matrici del sistema dinamico:');
sysc=ss(A,B,C,D)



%punto A
sysd=c2d(sysc,Ts,'zoh');
tfdisc=zpk(sysd);
fprintf('le matrici del sistema discretizzato attraverso lo zero order holder sono:');
sysd
fprintf('gli autovalori del sistema sono:');
eig(sysd)
fprintf('la funzione di trasferimento �');
tfdisc=zpk(sysd)
%variante con funzione di trasferimento 

%punto B
fprintf('la matrice di controllabilit� �');
ControllabilityMatrix=ctrb(sysd.A,sysd.B)
fprintf('il rango della matrice di controllabilit� � %d che coincide con la grandezza del sistema per cui posso assegnare gli autovalori \n', rank(ControllabilityMatrix));%� possibile l'assegnazione degli autovalori 

%assegnazione dei poli nel continuo in -1/2+j(rad(3)/2)

fprintf('gli autovalori che decido di assegnare nel continuo sono ');
polo1 =-0.5+j*(sqrt(3)/2)
polo2 =-0.5-j*(sqrt(3)/2)
%conversione da s -> z
fprintf('che convertiti nel discreto sono :');
polo1_d=exp(polo1*Ts)
polo2_d=exp(polo2*Ts)

poli_d=[polo1_d polo2_d];

%calcolo matrice dei guadagni assegnazione
fprintf('la matrice di assegazione degli autovalori � ');
K_d=acker(sysd.A,sysd.B,poli_d)%discreto


fprintf('per vedere se gli autovalori assegnati stanno effettivamente dove vogliamo bisogna controllare gli autovalori di A-KB, che sono\n');
%vogliamo
%
fprintf('eig(sysd.A-sysd.B*K_d)');
eig(sysd.A-sysd.B*K_d)
%
%in effetti l'assegnazione funziona

A_dr=sysd.A-sysd.B*K_d;%matrice A con assegnazione degli autovalori nel discreto
fprintf('a questo punto il sistema controreazionato prende la forma');
SystAssAutDiscreto=ss(A_dr,sysd.B,sysd.C,sysd.D,Ts) %sistema con assegnazione degli autovalori
fprintf('la funione di trasferimento quindi diventer�;');
tfSysdFaseMinima=zpk(SystAssAutDiscreto) %funzione di trasferimento


%punto C
fprintf('tutto molto bello, ma non abbiamo a disposizione la misura di entrambi gli stati :(\ndobbiamo quindi implementare un osservatore che ci dia la stima degli stati per poterli usare nell assegnazione degli autovalori');
%osservatore asintotico con due poli nell'origine
fprintf('vogliamo che i poli dell osservatore siano in 0');
poli_osservatore=0;
poli_Lc=[0 0];

%matrice del guadagno dell'osservatore,
%bisogna usare acker al posto di place perch� place non mette due poli nello stesso posto
fprintf('l osservatore avr� la matrice dei guadagni L in modo di avere una dinamica di convergenza dell errore assegnata');
fprintf('la matrice dei guadagni dell errore � ');
Lc=acker(sysd.A',sysd.C',poli_Lc)'
fprintf('la dinamica dell errore � definita dalla matrice A-L*C,nel nostro caso il sistema dinamico dell osservatore �');
eig(sysd.A-Lc*sysd.C)%poli dell'osservatore

%stima del disturbo 
fprintf('i sistemi per osservazione dello stato e assegnazione degli autovalori non tengono in considerazione la possibilit� di intervento del disturbo.\nPer rendere possibile la cancellazione del disturbo,bisogna definire un sistema aumentato nel quale una parte dello stato aumentato rappresenta lo stato e una parte il disturbo.\nNel nostro caso il sistema aumentato � definito come degue:');
Augumented_plant=ss([sysd.A sysd.B;0 0 1],[sysd.B;0],[sysd.C 0],0)%processo aumentato
fprintf('quindi per far convergere la stima del nuovo stato, devo definire i poli dell osservatore che saranno :');
poli_Lc_augumented=[0 0.1 0]%poli dell'osservatore del sistema aumentato
fprintf('la matrice dei guadagni dell osservatore �:');
lc_augumented=acker(Augumented_plant.A',Augumented_plant.C',poli_Lc_augumented);
Lc_augumented=lc_augumented' %matrice dei guadagni statici per la stima del sistama aumentato
%matrici dello stimatore

A_augumented=Augumented_plant.A-Lc_augumented*Augumented_plant.C;

%funzione di trasferimento del processo col controllo nello stato
fprintf('al momento il sistema controreazionato con stima dello stato e del disturbo � descritto dalle equazioni di stato:')
Ad=sysd.A-sysd.B*K_d
Bd=sysd.B
Cd=sysd.C
fprintf(' si pu� notare che la matrice Ad abbia avutovalori assegnati come richiesto e che ,grazie al principio di separazione la stima dello stato non influenza la dinamica dello stato');
%rlocus(ss(Ad,Bd,Cd,0))
% sysPPE sta per systema con PolePlacement e Estimators
fprintf('il nostro sistema al momento non ha guadagno unitario,si aggiunge quindi un guadagno a monte del sistema di controllo in modo che la specifica di guadagno unitario sia rispettata,in particolare questo guadagno vale :')
[Nx,Nu,Nbar]=refi(Ad,Bd,Cd,K_d);
NBar=Nbar/2; %guadagno statico per l'ingresso
Nbar

fprintf('calcolo del controllore deadbeat per ottenere errore nullo a regime per ingressi a gradino.Seguendo la teroia, avendo un sistema con zeri e poli a fase minima ,inverto la funzione e aggiungo integratore per avere un polo in z=1 nella catena diretta ');
%ingressia gradino
deadbeat=(1/(tfSysdFaseMinima*NBar))* tf([1],[1 -1],1)


P=tfSysdFaseMinima*NBar;



% Deadbeat for step input

% --------------------step responce with ripple---------------------------
z = tf('z');

l=1;
T=1/(z^l);                   %desired closed loop function for a step input

Drs= (1/(P))*(T/(1-T));      %Deadbeat Response  Step input with ripple

Su = Drs/(1+P*Drs);
F=Drs*P;                     %Openloop 
FB=feedback(F,1);

figure(1)
step(FB)
title('Step input response');
grid;
figure(2)
step(Su)
title('Control response with ripple');
grid;

%---------------------step responce without ripple-------------------------

l=2;

T=((0.29584*(z+0.9672))/0.58197645)/(z^l);     % desired closed loop funct-
                                               % -ion for a step input

Dwrs= (1/(P))*(T/(1-T));      %Deadbeat Response Step input without ripple

Su = Dwrs/(1+P*Dwrs);
F=Dwrs*P;
FB1=feedback(F,1);
figure(3)
step(FB1)
title('Step input response');
grid;
figure(4)
step(Su)
title('Control response without ripple');
grid;


% Deadbeat for ramp input

% --------------------ramp input responce with ripple---------------------

M=tf([ 2 -1],[1 0 0],1);                   % M=desired closedloop function

dwrr=(1/P)*(M/(1-M));                      %Deadbeat Response Ramp input 
                                           %with ripple

Gol=dwrr*P;

closedloop1= feedback(Gol,1);
% Plot
t=0:1:10;
alpha=1;
ramp=alpha*t;      % Your input signal
[y,t]=lsim(closedloop1,ramp,t);
figure(5)
plot(t,y,t,ramp,'r--');
title('Ramp input response');
grid;
xlabel('Time')
ylabel('Amplitude')
legend('output','reference')

