close all; clear all;

time_simulation = 100;                              %Duration of Simulation

sampling_time = 1;                                  %Sampling Time

t = 1:sampling_time:time_simulation;                %Time vector 


par=0;

%--------------------State Space Matricies Continuos Time------------------

a= 0.1;     

A = [ 0 1; 0 -a];

B = [0; a];

C = [1 0];

D = 0;

%--------------------------------------------------------------------------

sys = ss(A,B,C,D);

sysd = c2d(sys,sampling_time,'zoh');

%--------------------State Space Matricies Discrete------------------------

Ad = sysd.A;

Bd = sysd.B;

Cd = sysd.C;

Dd = 0;

poles_observer = [0 0]; 

L = acker(Ad',Cd',poles_observer)';

polo_1 = -0.5+1j*(sqrt(3)/2);
polo_2 = -0.5-1j*(sqrt(3)/2);

polo1_d=exp(polo_1*sampling_time);
polo2_d=exp(polo_2*sampling_time);

poles_system= [polo1_d,polo2_d];

K = acker(Ad,Bd,poles_system);

%--------------------------------------------------------------------------

%----------------------Deadbeat Design (z-transform)-----------------------

A_stab = Ad - Bd*K;                      %closed loop state space feedback 

[b,a] = ss2tf(A_stab,Bd,Cd,Dd,1);

Sys=tf(b,a,1);                   

M=tf([2 -1],[1 0 0],1);           %model transfer function for a ramp input

Dc = 1/Sys * (M/(1-M));

Dc_ss=ss(minreal(Dc));

%--------------------------------------------------------------------------

%---------------------------Deadbeat Time Domain---------------------------

A_c=Dc_ss.A;

B_c=Dc_ss.B;

C_c=Dc_ss.C;

D_c=Dc_ss.D;

K=[K 0];


A_aug = [ Ad,Bd; 0,0,1];

B_aug = [ Bd; 0];

C_aug = [ Cd, 0];


poles_observer = [0 0 0]; 

L_aug = acker(A_aug',C_aug',poles_observer)';


%----------------------------Augmented Plant----------------------------------

x_control = zeros(length(A_c),length(t));

x = zeros(3,time_simulation/sampling_time);
x_hat = zeros(3,time_simulation/sampling_time);
y = zeros(1,time_simulation/sampling_time);
m = zeros(1,time_simulation/sampling_time);              %controller output
u = zeros(1,time_simulation/sampling_time);              %reference input
tau = zeros(1,time_simulation/sampling_time);            %disturbance 
e = zeros(1,length(t));                                  %error between curent output and desired input

%--------------------------------------------------------------------------

%---------------------------------Input------------------------------------

for i=1:length(u)
    u(i)=5*i;
end
u(50:end) = 5*50;
%--------------------------------------------------------------------------
tau(30:40)=50;                                        %step disturbance

FB=0;                                                  %feedback connection
k = 1;


while par<time_simulation-sampling_time
  
     e(k)=(u(k)-FB);
  
    %------------------------Deadbeat Control------------------------------
  
     x_control(:,k+1) = A_c*x_control(:,k) + B_c*e(k) ;
     m(k) = C_c*x_control(:,k)+ D_c*e(k);
   
    %--------------------Augmented Plant State Space-----------------------
    
    x(:,k+1) = A_aug*x(:,k) + B_aug.*(m(k) - K*x_hat(:,k)+...
               tau(k) - x_hat(3,k));
    y(:,k) = C_aug*x(:,k);
    
   
    %----------------------------------------------------------------------
    
    FB =  C_aug*x(:,k+1);
    
    %-----------------------------Estimator--------------------------------

    x_hat(:,k+1) = A_aug*x_hat(:,k) + B_aug.*(m(k) - K*x_hat(:,k)...
                   - x_hat(3,k)) + L_aug.*(y(:,k) - C_aug*x_hat(:,k));
    
    par=par+sampling_time;
    
    k=k+1;
    
end

 stairs(t,tau,'r');
 hold on;
 stairs(t,x(1,:),'b');
 hold on;
 stairs(t,u(:),'g');
 hold on;
 stairs(t,x_hat(3,:),'k');
 
 
